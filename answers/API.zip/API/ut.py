import unittest
from app import app, db

class WeatherAPITest(unittest.TestCase):
    def setUp(self):
        self.app = app.test_client()
        with app.app_context():
            db.create_all()

    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()

    def test_get_weather(self):
        response = self.app.get("/api/weather")
        self.assertEqual(response.status_code, 200)

    def test_get_weather_stats(self):
        response = self.app.get("/api/weather/stats")
        self.assertEqual(response.status_code, 200)

if __name__ == "__main__":
    unittest.main()
