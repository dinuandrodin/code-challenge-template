#Define Database Models for Weather Data and Weather Sumary

from db import db

class WeatherData(db.Model):
    __tablename__ = "new_weather_data"
    id = db.Column(db.Integer, primary_key=True)
    station_id = db.Column(db.String, nullable=False)
    date = db.Column(db.String(8), nullable=False)  
    max_temp = db.Column(db.Integer)
    min_temp = db.Column(db.Integer)
    precipitation = db.Column(db.Integer)

class WeatherSummary(db.Model):
    __tablename__ = "weather_summary"
    id = db.Column(db.Integer, primary_key=True)
    station_id = db.Column(db.String, nullable=False)
    year = db.Column(db.String(4), nullable=False)  
    avg_max_temp = db.Column(db.Float)
    avg_min_temp = db.Column(db.Float)
    total_precipitation = db.Column(db.Float)