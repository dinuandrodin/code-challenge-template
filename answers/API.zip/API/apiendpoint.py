from flask import request, jsonify
from flask_restful import Resource, Api
from flasgger import Swagger
from db import db
from models import WeatherData, WeatherSummary

def init_api(app):
    api = Api(app)
    Swagger(app)

    class WeatherList(Resource):
        def get(self):
            """
            Get raw weather data with filtering and pagination
            ---
            parameters:
              - name: station_id
                in: query
                type: string
                required: false
              - name: date
                in: query
                type: string
                required: false
              - name: page
                in: query
                type: integer
                required: false
              - name: per_page
                in: query
                type: integer
                required: false
            responses:
              200:
                description: A list of weather data records
            """
            query = WeatherData.query
            if "station_id" in request.args:
                query = query.filter_by(station_id=request.args["station_id"])
            if "date" in request.args:
                query = query.filter_by(date=request.args["date"])
            
            page = int(request.args.get("page", 1))
            per_page = int(request.args.get("per_page", 10))
            records = query.paginate(page=page, per_page=per_page, error_out=False)

            return jsonify({
                "data": [record.__dict__ for record in records.items],
                "page": records.page,
                "total_pages": records.pages
            })

    class WeatherStats(Resource):
        def get(self):
            """
            Get yearly aggregated weather statistics with filtering and pagination
            ---
            parameters:
              - name: station_id
                in: query
                type: string
                required: false
              - name: year
                in: query
                type: string
                required: false
              - name: page
                in: query
                type: integer
                required: false
              - name: per_page
                in: query
                type: integer
                required: false
            responses:
              200:
                description: A list of weather statistics
            """
            query = WeatherSummary.query
            if "station_id" in request.args:
                query = query.filter_by(station_id=request.args["station_id"])
            if "year" in request.args:
                query = query.filter_by(year=request.args["year"])
            
            page = int(request.args.get("page", 1))
            per_page = int(request.args.get("per_page", 10))
            records = query.paginate(page=page, per_page=per_page, error_out=False)

            return jsonify({
                "data": [record.__dict__ for record in records.items],
                "page": records.page,
                "total_pages": records.pages
            })

    api.add_resource(WeatherList, "/api/weather")
    api.add_resource(WeatherStats, "/api/weather/stats")
